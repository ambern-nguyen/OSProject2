#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <pthread.h>
#include <limits.h>
#include "hash_functions.h"

#define KEEP 16 // only the first 16 bytes of a hash are kept

// Modified structure: add candidate_index for ordering
struct cracked_hash {
    char hash[2*KEEP+1];
    char *password;
    char *alg;
    int candidate_index;  // lower index means earlier candidate
};

typedef unsigned char * (*hashing)(unsigned char *, unsigned int);

int n_algs = 4;
hashing fn[4] = {calculate_md5, calculate_sha1, calculate_sha256, calculate_sha512};
char *algs[4] = {"MD5", "SHA1", "SHA256", "SHA512"};

// Compare two hexadecimal hash strings; returns 1 if equal.
int compare_hashes(char *a, char *b) {
    for (int i = 0; i < 2*KEEP; i++)
        if(a[i] != b[i])
            return 0;
    return 1;
}

// Structure to pass arguments to threads.
typedef struct {
    int start;                // start index (inclusive) in candidates array
    int end;                  // end index (exclusive)
    int n_hashed;             // number of hashed entries
    char **candidates;        // candidate password array
    struct cracked_hash *cracked_hashes; // array of hashed passwords
    pthread_spinlock_t *locks; // one spin lock per cracked_hash entry
} thread_arg;


void *thread_crack(void *arg) {
    thread_arg *targ = (thread_arg *) arg;
    for (int i = targ->start; i < targ->end; i++) {
        char *password = targ->candidates[i];
    
        for (int k = 0; k < n_algs; k++) {
            unsigned char *hash = fn[k]((unsigned char *)password, strlen(password));
            char hex_hash[2*KEEP+1];
            for (int j = 0; j < KEEP; j++)
                sprintf(&hex_hash[2*j], "%02x", hash[j]);
            hex_hash[2*KEEP] = '\0';
            free(hash);
           
            for (int j = 0; j < targ->n_hashed; j++) {
                if (compare_hashes(hex_hash, targ->cracked_hashes[j].hash)) {
                   
                    pthread_spin_lock(&targ->locks[j]);
                  
                    if (targ->cracked_hashes[j].password == NULL ||
                        i < targ->cracked_hashes[j].candidate_index) {
                        if (targ->cracked_hashes[j].password != NULL)
                            free(targ->cracked_hashes[j].password);
                        targ->cracked_hashes[j].password = strdup(password);
                        targ->cracked_hashes[j].alg = algs[k];
                        targ->cracked_hashes[j].candidate_index = i;
                    }
                    pthread_spin_unlock(&targ->locks[j]);
                }
            }
        }
    }
    return NULL;
}

void crack_hashed_passwords(char *password_list, char *hashed_list, char *output) {
    FILE *fp;
    char password[256];  // assume max length 255 characters
    char hex_hash[2*KEEP+1];

  
    int n_hashed = 0;
    struct cracked_hash *cracked_hashes;
    fp = fopen(hashed_list, "r");
    assert(fp != NULL);
    while (fscanf(fp, "%s", hex_hash) == 1)
        n_hashed++;
    rewind(fp);
    cracked_hashes = (struct cracked_hash *) malloc(n_hashed * sizeof(struct cracked_hash));
    assert(cracked_hashes != NULL);
    for (int i = 0; i < n_hashed; i++) {
        fscanf(fp, "%s", cracked_hashes[i].hash);
        cracked_hashes[i].password = NULL;
        cracked_hashes[i].alg = NULL;
        cracked_hashes[i].candidate_index = INT_MAX; 
    }
    fclose(fp);


    int n_candidates = 0;
    fp = fopen(password_list, "r");
    assert(fp != NULL);
    while (fscanf(fp, "%s", password) == 1)
        n_candidates++;
    rewind(fp);
    char **candidates = (char **) malloc(n_candidates * sizeof(char *));
    assert(candidates != NULL);
    int idx = 0;
    while (fscanf(fp, "%s", password) == 1) {
        candidates[idx] = strdup(password);
        idx++;
    }
    fclose(fp);

 
    pthread_spinlock_t *locks = (pthread_spinlock_t *) malloc(n_hashed * sizeof(pthread_spinlock_t));
    for (int i = 0; i < n_hashed; i++) {
        pthread_spin_init(&locks[i], PTHREAD_PROCESS_PRIVATE);
    }


    int n_threads = 6;
    pthread_t threads[n_threads];
    thread_arg targs[n_threads];
    int chunk = n_candidates / n_threads;
    int rem = n_candidates % n_threads;
    int start = 0;
    for (int i = 0; i < n_threads; i++) {
        int end = start + chunk + (i < rem ? 1 : 0);
        targs[i].start = start;
        targs[i].end = end;
        targs[i].n_hashed = n_hashed;
        targs[i].candidates = candidates;
        targs[i].cracked_hashes = cracked_hashes;
        targs[i].locks = locks;
        start = end;
        pthread_create(&threads[i], NULL, thread_crack, &targs[i]);
    }


    for (int i = 0; i < n_threads; i++) {
        pthread_join(threads[i], NULL);
    }


    fp = fopen(output, "w");
    assert(fp != NULL);
    for (int i = 0; i < n_hashed; i++) {
        if (cracked_hashes[i].password == NULL)
            fprintf(fp, "not found\n");
        else
            fprintf(fp, "%s:%s\n", cracked_hashes[i].password, cracked_hashes[i].alg);
    }
    fclose(fp);

    /* --- Clean up --- */
    for (int i = 0; i < n_hashed; i++) {
        pthread_spin_destroy(&locks[i]);
        free(cracked_hashes[i].password);
    }
    free((void *)locks);
    free(cracked_hashes);
    for (int i = 0; i < n_candidates; i++) {
        free(candidates[i]);
    }
    free(candidates);
}
